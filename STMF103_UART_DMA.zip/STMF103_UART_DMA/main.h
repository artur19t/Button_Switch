#ifndef _MAIN
#define _MAIN
#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <string.h>

#define RX_SIZE 20

#include "hw_init.h"
#include "usart_logic.h"
#include "it.h"
#endif
#ifndef _IT
#define _IT
#include "main.h"
extern uint8_t RxBuf[];
void USART1_IRQHandler (void);
#endif